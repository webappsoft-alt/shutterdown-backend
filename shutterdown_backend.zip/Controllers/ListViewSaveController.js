// // const addClientSchema=require('../Schema/AddClientSchema')

// const ListViewSaveController=(req,res)=>{
// console.log(req.params,"params")
// try {
//     // const user=await addClientSchema.findOne({userID:req.params.id})
//   console.log(req.body,"user")
//     // res.status(200).json(user)
    
// } catch (error) {
//     console.log(error)   
// }
// }



// module.exports={ListViewSaveController}