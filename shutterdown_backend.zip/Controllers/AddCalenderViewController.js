
const AddClientTeamFunction=(req,res)=>{
    try {
        console.log(req.body,"body")
        
    } catch (error) {
        
    }
}


module.exports={AddClientTeamFunction}