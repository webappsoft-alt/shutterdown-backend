 const userSchema=require('../Schema/userSchema')
 const CalenderList=(req,res)=>{
try {
   console.log("function runs")
    
} catch (error) {
    console.log(error,"error")
}
 }
 module.exports={CalenderList}